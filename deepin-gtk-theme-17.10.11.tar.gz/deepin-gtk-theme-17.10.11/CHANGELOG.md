#17.10.11
  update close icons
#17.10.10
  update titlebar styles
## 17.10.9 (2018-10-25)


#### Bug Fixes

*   make gedit's close button on 1x env clear ([12f809d7](12f809d7))
*   close button looks misplaced ([edcf146c](edcf146c))
*   bold window title ([d760085b](d760085b))
*   make titlebar height larger ([16f6ebbe](16f6ebbe))
*   Adapt lintian ([00314280](00314280))



# 17.10.8
   Fix a metacity bug
# 17.10.7
    Improve HiDPI support.
