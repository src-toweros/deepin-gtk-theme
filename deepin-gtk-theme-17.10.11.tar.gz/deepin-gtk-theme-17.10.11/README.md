Deepin GTK Theme - for gtk version 3.18
